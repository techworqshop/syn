--
-- PostgreSQL database dump
--

\restrict vXh5eHmItFXDbaGAczDAUYueKAMXntUqakfsZyN02aLD8yCQcxbfEtBQW9u0TFO

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    actor_email text NOT NULL,
    action text NOT NULL,
    target_type text,
    target_id uuid,
    metadata jsonb,
    ip text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_audit_log OWNER TO synweb_prod;

--
-- Name: audience_messages; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.audience_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    persona_slot integer NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audience_messages OWNER TO synweb_prod;

--
-- Name: billing_events; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id text NOT NULL,
    event_type text NOT NULL,
    user_id uuid,
    payload jsonb NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.billing_events OWNER TO synweb_prod;

--
-- Name: email_change_tokens; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.email_change_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    new_email text NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_change_tokens OWNER TO synweb_prod;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.email_verification_tokens OWNER TO synweb_prod;

--
-- Name: files; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.files (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    file_name text NOT NULL,
    mime_type text NOT NULL,
    storage_path text NOT NULL,
    summary text,
    size_bytes integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    category text DEFAULT 'panel'::text NOT NULL,
    locked boolean DEFAULT false NOT NULL
);


ALTER TABLE public.files OWNER TO synweb_prod;

--
-- Name: invites; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.invites (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    invited_by uuid NOT NULL,
    used_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '14 days'::interval) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invites OWNER TO synweb_prod;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    role text NOT NULL,
    persona_slot integer,
    persona_name text,
    content text NOT NULL,
    round_number integer,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.messages OWNER TO synweb_prod;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO synweb_prod;

--
-- Name: persona_images; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.persona_images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    slot integer NOT NULL,
    storage_path text,
    mime_type text DEFAULT 'image/png'::text NOT NULL,
    status text DEFAULT 'ready'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    generated_name text
);


ALTER TABLE public.persona_images OWNER TO synweb_prod;

--
-- Name: personas; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.personas (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    slot integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    core_perspective text NOT NULL,
    profile text NOT NULL,
    position_summary text,
    round_1_response text,
    round_2_response text,
    round_3_response text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.personas OWNER TO synweb_prod;

--
-- Name: purchased_extras; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.purchased_extras (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    quantity integer NOT NULL,
    chargebee_invoice_id text,
    chargebee_charge_id text,
    unit_price_eur integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    quantity_used integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.purchased_extras OWNER TO synweb_prod;

--
-- Name: session_consumptions; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.session_consumptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    session_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    credit_id uuid
);


ALTER TABLE public.session_consumptions OWNER TO synweb_prod;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text DEFAULT 'Neue Fokusgruppe'::text NOT NULL,
    problem_brief text,
    status text DEFAULT 'discovery'::text NOT NULL,
    rigidity_score integer DEFAULT 5 NOT NULL,
    persona_count integer DEFAULT 0 NOT NULL,
    current_round integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    title_locked boolean DEFAULT false NOT NULL,
    share_token text,
    locale text DEFAULT 'de'::text NOT NULL,
    first_message_at timestamp with time zone,
    archived_at timestamp with time zone
);


ALTER TABLE public.sessions OWNER TO synweb_prod;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    chargebee_customer_id text NOT NULL,
    chargebee_subscription_id text,
    status text DEFAULT 'inactive'::text NOT NULL,
    plan_item_price_id text,
    current_term_start timestamp with time zone,
    current_term_end timestamp with time zone,
    trial_end timestamp with time zone,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    scheduled_plan_item_price_id text,
    scheduled_change_at timestamp with time zone,
    pause_date timestamp with time zone,
    resume_date timestamp with time zone
);


ALTER TABLE public.subscriptions OWNER TO synweb_prod;

--
-- Name: syntheses; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.syntheses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    round_number integer NOT NULL,
    synthesis_text text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.syntheses OWNER TO synweb_prod;

--
-- Name: users; Type: TABLE; Schema: public; Owner: synweb_prod
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text,
    must_change_password text DEFAULT 'true'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    email_verified_at timestamp with time zone,
    deletion_requested_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO synweb_prod;

--
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.admin_audit_log (id, actor_id, actor_email, action, target_type, target_id, metadata, ip, created_at) FROM stdin;
fdb77190-c4de-420a-960c-2ece4eda4181	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	4bc9d45d-b2d6-48fa-af5e-4a7efe1973e5	{"title": "Mongoose: Test-Fokusgruppen-Diskussion", "createdAt": "2026-05-19T20:16:54.025Z", "currentRound": 1, "filesDeleted": 0, "personaCount": 3}	\N	2026-05-20 01:04:52.078044+02
16cfba1a-4aa8-4490-bcde-d617dc5cc350	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	8a3b5fa8-5656-4238-84a9-b035e3212c61	{"title": "Boruto: Persona-Profile entwickeln", "createdAt": "2026-05-20T12:21:54.380Z", "currentRound": 1, "filesDeleted": 0, "personaCount": 5}	\N	2026-05-20 14:43:23.477077+02
cec4fcb3-1563-462e-8aba-2c41513ec9f2	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	b38eb120-dc45-4ba3-b730-7b7bd622f193	{"title": "Fokusgruppe: Mikrofone erkunden", "createdAt": "2026-05-20T12:43:24.571Z", "currentRound": 3, "filesDeleted": 0, "personaCount": 4}	\N	2026-05-20 15:15:38.275426+02
0e1c7277-b563-43c1-a439-be8abb43a6d8	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	c4364606-db95-4f26-95f2-f9dad5e29cf1	{"title": "Arbeitssicherheit: Persona-Fokusgruppen-Test", "createdAt": "2026-05-20T17:41:30.070Z", "currentRound": 0, "filesDeleted": 0, "personaCount": 5}	\N	2026-05-20 19:59:05.966561+02
62baf71b-6d65-4eb2-8bf0-1d68d9cd3540	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	44a43961-316e-489a-85fc-d1890541f68c	{"title": "Alpaka Fokusgruppe", "createdAt": "2026-05-20T18:09:08.617Z", "currentRound": 0, "filesDeleted": 0, "personaCount": 1}	\N	2026-05-20 20:22:57.112508+02
b563d58e-af73-4306-9ce3-8ceacd98a843	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	296b463b-5406-461a-a105-cbefd7bfaba9	{"title": "Nutzerfeedback zu Alpaka-Essbehältern", "createdAt": "2026-05-20T18:22:58.660Z", "currentRound": 1, "filesDeleted": 0, "personaCount": 4}	\N	2026-05-20 20:36:48.638132+02
a720ebbc-0d49-4569-b0ce-17779e56c77c	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	3ac271b5-385a-47c6-b734-955005ee8c70	{"title": "Fokusgruppen-Diskussion Gänse", "createdAt": "2026-05-20T18:36:49.634Z", "currentRound": 0, "filesDeleted": 0, "personaCount": 4}	\N	2026-05-20 21:04:20.392758+02
06f27f6a-751d-4300-8326-4d4c8217bfd8	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	004cbead-ed4a-4151-9deb-208318846550	{"title": "Bitburger 0.0: Meinungen & Eindrücke", "createdAt": "2026-05-20T19:04:21.558Z", "currentRound": 0, "filesDeleted": 0, "personaCount": 4}	\N	2026-05-20 21:12:50.337766+02
0fcb4c22-0b4d-4230-9448-bb84ae0ab3dc	7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	session.delete_own	session	9db1e473-97af-4d29-8fc8-4bfdc97ce071	{"title": "Wispr Flow: Testgruppen-Konzept", "createdAt": "2026-05-20T19:12:51.030Z", "currentRound": 0, "filesDeleted": 0, "personaCount": 4}	\N	2026-05-20 23:16:31.954736+02
\.


--
-- Data for Name: audience_messages; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.audience_messages (id, session_id, persona_slot, role, content, created_at) FROM stdin;
\.


--
-- Data for Name: billing_events; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.billing_events (id, event_id, event_type, user_id, payload, received_at) FROM stdin;
e01b811e-107c-4f12-a857-ecb42e98316b	ev_198TQ9VNHMZbG1HyT	subscription_ramp_deleted	\N	{"id": "ev_198TQ9VNHMZbG1HyT", "object": "event", "source": "scheduled_job", "content": {"ramp": {"id": "sch_mig106674", "object": "ramp", "status": "scheduled", "deleted": true, "created_at": 1779787044, "updated_at": 1782134935, "items_to_add": [{"amount": 15000, "object": "items_to_add", "quantity": 1, "item_type": "plan", "unit_price": 15000, "free_quantity": 0, "item_price_id": "syn-basic-monthly-eur"}], "effective_from": 1782134934, "items_to_remove": ["syn-pro-monthly-eur"], "subscription_id": "198iYBVKM5ReChlG", "resource_version": 1782134935998}}, "webhooks": [{"id": "whv1_BTLtqwVMKRgF15KF", "object": "webhook", "webhook_status": "scheduled"}, {"id": "whv2_199XGPVKGocxVYUR", "object": "webhook", "webhook_status": "scheduled"}], "event_type": "subscription_ramp_deleted", "api_version": "v2", "occurred_at": 1782134936, "webhook_status": "not_configured"}	2026-06-22 15:28:56.40383+02
dba2eeda-2697-408c-86fd-3bcc6a50cdb0	ev_198OBLVNSGdJzAbL	invoice_generated	\N	{"id": "ev_198OBLVNSGdJzAbL", "object": "event", "source": "scheduled_job", "content": {"invoice": {"id": "9", "tax": 17100, "date": 1782296058, "taxes": [{"name": "VAT", "amount": 17100, "object": "tax", "description": "VAT @ 19 %"}], "total": 107100, "object": "invoice", "status": "paid", "channel": "web", "deleted": false, "paid_at": 1782296059, "due_date": 1782296058, "is_gifted": false, "recurring": true, "sub_total": 90000, "amount_due": 0, "is_digital": true, "line_items": [{"id": "li_198OBLVNSGdE6AbF", "amount": 90000, "object": "line_item", "date_to": 1784888058, "is_taxed": true, "quantity": 1, "tax_rate": 19, "date_from": 1782296058, "entity_id": "syn-enterprise-monthly-eur", "tax_amount": 17100, "customer_id": "ab52aeb2-2fa3-41f5-8ca7-da03787d2bbd", "description": "Syn Enterprise - Monthly", "entity_type": "plan_item_price", "unit_amount": 90000, "pricing_model": "flat_fee", "discount_amount": 0, "subscription_id": "198iYBVKX02eU5VKR", "item_level_discount_amount": 0}], "price_type": "tax_exclusive", "tax_origin": {"country": "DE"}, "tax_source": "chargebee_tax", "updated_at": 1782296059, "vat_number": "DE453210797", "amount_paid": 107100, "customer_id": "ab52aeb2-2fa3-41f5-8ca7-da03787d2bbd", "generated_at": 1782296058, "currency_code": "EUR", "exchange_rate": 1, "first_invoice": false, "linked_orders": [], "net_term_days": 0, "term_finalized": true, "amount_adjusted": 0, "applied_credits": [], "billing_address": {"zip": "12103", "city": "Berlin", "line1": "In den Alboingaerten 17", "object": "billing_address", "company": "Worqshop IO UG", "country": "DE", "last_name": "Zyrek", "first_name": "Lukasz", "validation_status": "not_validated"}, "credits_applied": 0, "line_item_taxes": [{"object": "line_item_tax", "tax_name": "VAT", "tax_rate": 19, "tax_amount": 17100, "line_item_id": "li_198OBLVNSGdE6AbF", "tax_juris_code": "DE", "tax_juris_name": "Germany", "tax_juris_type": "country", "taxable_amount": 90000, "is_non_compliance_tax": false, "is_partial_tax_applied": false}], "linked_payments": [{"txn_id": "txn_198OBLVNSGdGCAbH", "txn_date": 1782296059, "applied_at": 1782296059, "txn_amount": 107100, "txn_status": "success", "applied_amount": 107100}], "subscription_id": "198iYBVKX02eU5VKR", "dunning_attempts": [], "resource_version": 1782296059895, "round_off_amount": 0, "write_off_amount": 0, "amount_to_collect": 0, "base_currency_code": "EUR", "has_advance_charges": false, "issued_credit_notes": [], "reference_transactions": [{"txn_id": "txn_198OBLVNSGdGCAbH", "txn_date": 1782296059, "txn_type": "payment", "applied_at": 1782296059, "txn_amount": 107100, "txn_status": "success", "applied_amount": 107100}], "adjustment_credit_notes": [], "site_details_at_creation": {"timezone": "Europe/Berlin", "organization_address": {"zip": "12103", "city": "Berlin", "email": "tech@worqshop.io", "line1": "In den Alboingärten 17", "phone": "+49 17683340358", "state": "Berlin", "website": "https://worqshop.io/", "country_code": "DE", "organization_name": "Worqshop IO UG"}}}}, "webhooks": [{"id": "whv1_BTLtqwVMKRgF15KF", "object": "webhook", "webhook_status": "scheduled"}, {"id": "whv2_199XGPVKGocxVYUR", "object": "webhook", "webhook_status": "scheduled"}], "event_type": "invoice_generated", "api_version": "v2", "occurred_at": 1782296060, "webhook_status": "not_configured"}	2026-06-24 12:14:20.28826+02
e3928cbb-ac2e-48a9-95c6-01a796391e29	ev_BTM67vVNd5GP6BvU	invoice_generated	\N	{"id": "ev_BTM67vVNd5GP6BvU", "object": "event", "source": "scheduled_job", "content": {"invoice": {"id": "10", "tax": 7350, "date": 1782455888, "taxes": [{"name": "VAT", "amount": 7350, "object": "tax", "description": "VAT @ 21 %"}], "total": 42350, "object": "invoice", "status": "paid", "channel": "web", "deleted": false, "paid_at": 1782455889, "due_date": 1782455888, "is_gifted": false, "recurring": true, "sub_total": 35000, "amount_due": 0, "is_digital": true, "line_items": [{"id": "li_BTM67vVNd5GJkBvO", "amount": 35000, "object": "line_item", "date_to": 1785047888, "is_taxed": true, "quantity": 1, "tax_rate": 21, "date_from": 1782455888, "entity_id": "syn-pro-monthly-eur", "tax_amount": 7350, "customer_id": "7fbb8f46-e34d-4bd9-8465-db10e4d7ac4e", "description": "Syn Pro - Monthly", "entity_type": "plan_item_price", "unit_amount": 35000, "pricing_model": "flat_fee", "discount_amount": 0, "subscription_id": "BTM8OeVKhofrD7YI", "item_level_discount_amount": 0}], "price_type": "tax_exclusive", "tax_origin": {"country": "ES"}, "tax_source": "chargebee_tax", "updated_at": 1782455889, "amount_paid": 42350, "customer_id": "7fbb8f46-e34d-4bd9-8465-db10e4d7ac4e", "generated_at": 1782455888, "currency_code": "EUR", "exchange_rate": 1, "first_invoice": false, "linked_orders": [], "net_term_days": 0, "term_finalized": true, "amount_adjusted": 0, "applied_credits": [], "billing_address": {"zip": "08038", "city": "Barcelona", "line1": "Carrer de la Mineria", "line2": "Sants-Montjuïc", "state": "Catalunya", "object": "billing_address", "company": "Johannes", "country": "ES", "last_name": "Jolkkonen", "first_name": "Johannes", "validation_status": "not_validated"}, "credits_applied": 0, "line_item_taxes": [{"object": "line_item_tax", "tax_name": "VAT", "tax_rate": 21, "tax_amount": 7350, "line_item_id": "li_BTM67vVNd5GJkBvO", "tax_juris_code": "ES", "tax_juris_name": "Spain", "tax_juris_type": "country", "taxable_amount": 35000, "is_non_compliance_tax": false, "is_partial_tax_applied": false}], "linked_payments": [{"txn_id": "txn_BTM67vVNd5GLZBvQ", "txn_date": 1782455889, "applied_at": 1782455889, "txn_amount": 42350, "txn_status": "success", "applied_amount": 42350}], "subscription_id": "BTM8OeVKhofrD7YI", "dunning_attempts": [], "resource_version": 1782455889905, "round_off_amount": 0, "write_off_amount": 0, "amount_to_collect": 0, "base_currency_code": "EUR", "has_advance_charges": false, "issued_credit_notes": [], "reference_transactions": [{"txn_id": "txn_BTM67vVNd5GLZBvQ", "txn_date": 1782455889, "txn_type": "payment", "applied_at": 1782455889, "txn_amount": 42350, "txn_status": "success", "applied_amount": 42350}], "adjustment_credit_notes": [], "site_details_at_creation": {"timezone": "Europe/Berlin", "organization_address": {"zip": "12103", "city": "Berlin", "email": "tech@worqshop.io", "line1": "In den Alboingärten 17", "phone": "+49 17683340358", "state": "Berlin", "website": "https://worqshop.io/", "country_code": "DE", "organization_name": "Worqshop IO UG"}}}}, "webhooks": [{"id": "whv1_BTLtqwVMKRgF15KF", "object": "webhook", "webhook_status": "scheduled"}, {"id": "whv2_199XGPVKGocxVYUR", "object": "webhook", "webhook_status": "scheduled"}], "event_type": "invoice_generated", "api_version": "v2", "occurred_at": 1782455890, "webhook_status": "not_configured"}	2026-06-26 08:38:10.281196+02
9bab5c98-bf30-44c7-8bb7-4ac639cba6ae	ev_199ET3VNf1M9v10Yo	invoice_generated	\N	{"id": "ev_199ET3VNf1M9v10Yo", "object": "event", "source": "scheduled_job", "content": {"invoice": {"id": "11", "tax": 2850, "date": 1782484510, "taxes": [{"name": "VAT", "amount": 2850, "object": "tax", "description": "VAT @ 19 %"}], "total": 17850, "object": "invoice", "status": "paid", "channel": "web", "deleted": false, "paid_at": 1782484511, "due_date": 1782484510, "is_gifted": false, "recurring": true, "sub_total": 15000, "amount_due": 0, "is_digital": true, "line_items": [{"id": "li_199ET3VNf1M5010Yg", "amount": 15000, "object": "line_item", "date_to": 1785076510, "is_taxed": true, "quantity": 1, "tax_rate": 19, "date_from": 1782484510, "entity_id": "syn-basic-monthly-eur", "tax_amount": 2850, "customer_id": "ff2b984e-2475-49d3-adbf-93aef69176f6", "description": "Syn Basic - Monthly", "entity_type": "plan_item_price", "unit_amount": 15000, "pricing_model": "flat_fee", "discount_amount": 0, "subscription_id": "19ANGqVKjkjwepuf", "item_level_discount_amount": 0}], "price_type": "tax_exclusive", "tax_origin": {"country": "DE"}, "tax_source": "chargebee_tax", "updated_at": 1782484511, "amount_paid": 17850, "customer_id": "ff2b984e-2475-49d3-adbf-93aef69176f6", "generated_at": 1782484510, "currency_code": "EUR", "exchange_rate": 1, "first_invoice": false, "linked_orders": [], "net_term_days": 0, "term_finalized": true, "amount_adjusted": 0, "applied_credits": [], "billing_address": {"zip": "12345", "city": "Smöreksen", "line1": "Smörekstreet", "object": "billing_address", "company": "Smörekhausen", "country": "DE", "last_name": "El Lörek", "first_name": "Smörek", "validation_status": "not_validated"}, "credits_applied": 0, "line_item_taxes": [{"object": "line_item_tax", "tax_name": "VAT", "tax_rate": 19, "tax_amount": 2850, "line_item_id": "li_199ET3VNf1M5010Yg", "tax_juris_code": "DE", "tax_juris_name": "Germany", "tax_juris_type": "country", "taxable_amount": 15000, "is_non_compliance_tax": false, "is_partial_tax_applied": false}], "linked_payments": [{"txn_id": "txn_199ET3VNf1M6j10Yi", "txn_date": 1782484511, "applied_at": 1782484511, "txn_amount": 17850, "txn_status": "success", "applied_amount": 17850}], "subscription_id": "19ANGqVKjkjwepuf", "dunning_attempts": [], "resource_version": 1782484511399, "round_off_amount": 0, "write_off_amount": 0, "amount_to_collect": 0, "base_currency_code": "EUR", "has_advance_charges": false, "issued_credit_notes": [], "reference_transactions": [{"txn_id": "txn_199ET3VNf1M6j10Yi", "txn_date": 1782484511, "txn_type": "payment", "applied_at": 1782484511, "txn_amount": 17850, "txn_status": "success", "applied_amount": 17850}], "adjustment_credit_notes": [], "site_details_at_creation": {"timezone": "Europe/Berlin", "organization_address": {"zip": "12103", "city": "Berlin", "email": "tech@worqshop.io", "line1": "In den Alboingärten 17", "phone": "+49 17683340358", "state": "Berlin", "website": "https://worqshop.io/", "country_code": "DE", "organization_name": "Worqshop IO UG"}}}}, "webhooks": [{"id": "whv1_BTLtqwVMKRgF15KF", "object": "webhook", "webhook_status": "scheduled"}, {"id": "whv2_199XGPVKGocxVYUR", "object": "webhook", "webhook_status": "scheduled"}], "event_type": "invoice_generated", "api_version": "v2", "occurred_at": 1782484511, "webhook_status": "not_configured"}	2026-06-26 16:35:11.751268+02
\.


--
-- Data for Name: email_change_tokens; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.email_change_tokens (id, user_id, new_email, token, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.email_verification_tokens (id, user_id, token, expires_at, used_at, created_at) FROM stdin;
e44e38f6-8cc8-4deb-b6db-f988ff82c3d0	7d205911-0b11-4913-99e1-6ee06e1cff63	48c8d139ffe29edf9df8d69f23aadd152ad6217a2aa1fe773884f2f2b6b09166	2026-05-19 23:03:58.794+02	2026-05-18 23:04:38.905+02	2026-05-18 23:03:58.795442+02
2ad2dda7-5be5-48a3-8e1c-20f1ac4ed64e	a6573fb5-7077-429d-aa27-a29b0e6b183c	d2c9a3c77306d51a05af89259da3e6a0bfd2729ba4649a07f3fd6eb8159adc02	2026-05-19 23:05:35.916+02	\N	2026-05-18 23:05:35.917112+02
66bf6ca1-66ea-4b96-8aaf-a93e2d48f36b	a6573fb5-7077-429d-aa27-a29b0e6b183c	19126a3133df9061e2e50b64466a002807da0a1ea4d71d86422facfa784c8764	2026-05-19 23:05:34.843+02	2026-05-18 23:05:53.551+02	2026-05-18 23:05:34.84423+02
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.files (id, session_id, file_name, mime_type, storage_path, summary, size_bytes, created_at, category, locked) FROM stdin;
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.invites (id, email, token, invited_by, used_at, expires_at, created_at) FROM stdin;
4e2323db-82d4-4ed3-a28e-4281dcc1f997	lukasz.zyrek.uy@gmail.com	e8vTH43VzVdp1pxs61tlF-U1MUJcJ6sn	d5c1940c-9f6d-491c-bb52-646ecb861e3c	\N	2026-05-31 23:14:06.346+02	2026-05-17 23:14:06.349129+02
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.messages (id, session_id, role, persona_slot, persona_name, content, round_number, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: persona_images; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.persona_images (id, session_id, slot, storage_path, mime_type, status, created_at, attempts, last_error, generated_name) FROM stdin;
\.


--
-- Data for Name: personas; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.personas (id, session_id, slot, name, type, core_perspective, profile, position_summary, round_1_response, round_2_response, round_3_response, created_at) FROM stdin;
\.


--
-- Data for Name: purchased_extras; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.purchased_extras (id, user_id, period_start, quantity, chargebee_invoice_id, chargebee_charge_id, unit_price_eur, created_at, expires_at, quantity_used) FROM stdin;
\.


--
-- Data for Name: session_consumptions; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.session_consumptions (id, user_id, session_id, period_start, consumed_at, created_at, credit_id) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.sessions (id, user_id, title, problem_brief, status, rigidity_score, persona_count, current_round, created_at, updated_at, title_locked, share_token, locale, first_message_at, archived_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.subscriptions (id, user_id, chargebee_customer_id, chargebee_subscription_id, status, plan_item_price_id, current_term_start, current_term_end, trial_end, cancelled_at, created_at, updated_at, scheduled_plan_item_price_id, scheduled_change_at, pause_date, resume_date) FROM stdin;
\.


--
-- Data for Name: syntheses; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.syntheses (id, session_id, round_number, synthesis_text, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: synweb_prod
--

COPY public.users (id, email, password_hash, name, must_change_password, created_at, updated_at, is_admin, email_verified_at, deletion_requested_at) FROM stdin;
d5c1940c-9f6d-491c-bb52-646ecb861e3c	lukasz@worqshop.io	$2a$10$.9z1wf3E0Y7/kLlsBByrPOP5BP6/FipgdmvHG4yqm5t7qH5Xo1ewa	\N	false	2026-05-17 22:59:18.224671+02	2026-05-17 22:59:18.224671+02	t	2026-05-17 22:59:18.223+02	\N
32ed9367-139b-4726-b5fd-2514a6c8b35e	lorenz@worqshop.io	$2a$10$.AeaEob7YN9l60MeiGta3OYZIobYKgj7Fz2f1f6140vr8lk5bmASi	\N	false	2026-05-17 23:50:39.440559+02	2026-05-17 23:50:39.440559+02	t	2026-05-17 23:50:39.438+02	\N
a6573fb5-7077-429d-aa27-a29b0e6b183c	lukasz+2@worqshop.io	$2a$10$t8FB0JdEqxojrVtpSSVuSeRCEfJV6JgiM04LHLvC/ohSnWWoRq0fG	\N	false	2026-05-18 23:05:34.834977+02	2026-05-18 23:05:53.549+02	t	2026-05-18 23:05:53.549+02	\N
7d205911-0b11-4913-99e1-6ee06e1cff63	lukasz+1@worqshop.io	$2a$10$obKbMbCOpXBAzSO/KuTdZ.AY4WqiupW.eF5ZLh24lEvW1zJFGlPBW	\N	false	2026-05-18 23:03:58.792371+02	2026-05-18 23:04:38.899+02	f	2026-05-18 23:04:38.899+02	\N
\.


--
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- Name: audience_messages audience_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.audience_messages
    ADD CONSTRAINT audience_messages_pkey PRIMARY KEY (id);


--
-- Name: billing_events billing_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_event_id_key UNIQUE (event_id);


--
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- Name: email_change_tokens email_change_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.email_change_tokens
    ADD CONSTRAINT email_change_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_change_tokens email_change_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.email_change_tokens
    ADD CONSTRAINT email_change_tokens_token_key UNIQUE (token);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_key UNIQUE (token);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: invites invites_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (id);


--
-- Name: invites invites_token_key; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_token_key UNIQUE (token);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: persona_images persona_images_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.persona_images
    ADD CONSTRAINT persona_images_pkey PRIMARY KEY (id);


--
-- Name: personas personas_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_pkey PRIMARY KEY (id);


--
-- Name: purchased_extras purchased_extras_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.purchased_extras
    ADD CONSTRAINT purchased_extras_pkey PRIMARY KEY (id);


--
-- Name: session_consumptions session_consumptions_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.session_consumptions
    ADD CONSTRAINT session_consumptions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: syntheses syntheses_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.syntheses
    ADD CONSTRAINT syntheses_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: admin_audit_log_action_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX admin_audit_log_action_idx ON public.admin_audit_log USING btree (action);


--
-- Name: admin_audit_log_actor_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX admin_audit_log_actor_idx ON public.admin_audit_log USING btree (actor_id);


--
-- Name: admin_audit_log_created_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX admin_audit_log_created_idx ON public.admin_audit_log USING btree (created_at DESC);


--
-- Name: audience_session_persona_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX audience_session_persona_idx ON public.audience_messages USING btree (session_id, persona_slot);


--
-- Name: billing_events_received_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX billing_events_received_idx ON public.billing_events USING btree (received_at DESC);


--
-- Name: billing_events_type_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX billing_events_type_idx ON public.billing_events USING btree (event_type);


--
-- Name: email_change_tokens_token_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX email_change_tokens_token_idx ON public.email_change_tokens USING btree (token);


--
-- Name: email_change_tokens_user_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX email_change_tokens_user_idx ON public.email_change_tokens USING btree (user_id);


--
-- Name: email_verification_tokens_token_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX email_verification_tokens_token_idx ON public.email_verification_tokens USING btree (token);


--
-- Name: email_verification_tokens_user_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX email_verification_tokens_user_idx ON public.email_verification_tokens USING btree (user_id);


--
-- Name: files_category_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX files_category_idx ON public.files USING btree (category);


--
-- Name: files_session_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX files_session_idx ON public.files USING btree (session_id);


--
-- Name: invites_email_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX invites_email_idx ON public.invites USING btree (email);


--
-- Name: invites_token_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX invites_token_idx ON public.invites USING btree (token);


--
-- Name: messages_session_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX messages_session_idx ON public.messages USING btree (session_id);


--
-- Name: password_reset_tokens_token_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX password_reset_tokens_token_idx ON public.password_reset_tokens USING btree (token);


--
-- Name: password_reset_tokens_user_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX password_reset_tokens_user_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: persona_images_session_slot_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE UNIQUE INDEX persona_images_session_slot_idx ON public.persona_images USING btree (session_id, slot);


--
-- Name: personas_session_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX personas_session_idx ON public.personas USING btree (session_id);


--
-- Name: purchased_extras_expires_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX purchased_extras_expires_idx ON public.purchased_extras USING btree (expires_at);


--
-- Name: purchased_extras_invoice_unique; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE UNIQUE INDEX purchased_extras_invoice_unique ON public.purchased_extras USING btree (chargebee_invoice_id) WHERE (chargebee_invoice_id IS NOT NULL);


--
-- Name: purchased_extras_user_avail_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX purchased_extras_user_avail_idx ON public.purchased_extras USING btree (user_id, expires_at);


--
-- Name: purchased_extras_user_period_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX purchased_extras_user_period_idx ON public.purchased_extras USING btree (user_id, period_start);


--
-- Name: session_consumptions_session_unique; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE UNIQUE INDEX session_consumptions_session_unique ON public.session_consumptions USING btree (session_id);


--
-- Name: session_consumptions_user_period_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX session_consumptions_user_period_idx ON public.session_consumptions USING btree (user_id, period_start);


--
-- Name: sessions_archived_at_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX sessions_archived_at_idx ON public.sessions USING btree (archived_at);


--
-- Name: sessions_share_token_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE UNIQUE INDEX sessions_share_token_idx ON public.sessions USING btree (share_token) WHERE (share_token IS NOT NULL);


--
-- Name: sessions_user_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX sessions_user_idx ON public.sessions USING btree (user_id);


--
-- Name: subscriptions_cb_customer_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX subscriptions_cb_customer_idx ON public.subscriptions USING btree (chargebee_customer_id);


--
-- Name: subscriptions_cb_sub_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX subscriptions_cb_sub_idx ON public.subscriptions USING btree (chargebee_subscription_id);


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_user_unique; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE UNIQUE INDEX subscriptions_user_unique ON public.subscriptions USING btree (user_id);


--
-- Name: syntheses_session_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX syntheses_session_idx ON public.syntheses USING btree (session_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: synweb_prod
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: admin_audit_log admin_audit_log_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audience_messages audience_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.audience_messages
    ADD CONSTRAINT audience_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: billing_events billing_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: email_change_tokens email_change_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.email_change_tokens
    ADD CONSTRAINT email_change_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: files files_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: invites invites_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT invites_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: persona_images persona_images_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.persona_images
    ADD CONSTRAINT persona_images_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: personas personas_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: purchased_extras purchased_extras_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.purchased_extras
    ADD CONSTRAINT purchased_extras_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: session_consumptions session_consumptions_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.session_consumptions
    ADD CONSTRAINT session_consumptions_credit_id_fkey FOREIGN KEY (credit_id) REFERENCES public.purchased_extras(id) ON DELETE SET NULL;


--
-- Name: session_consumptions session_consumptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.session_consumptions
    ADD CONSTRAINT session_consumptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: syntheses syntheses_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: synweb_prod
--

ALTER TABLE ONLY public.syntheses
    ADD CONSTRAINT syntheses_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict vXh5eHmItFXDbaGAczDAUYueKAMXntUqakfsZyN02aLD8yCQcxbfEtBQW9u0TFO

